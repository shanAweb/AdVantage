// Production server entry point
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'https://rankandrun.com',
  credentials: true
}));

app.use(helmet());
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// Logging
app.use(morgan('combined'));

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'production'
  });
});

// API ping
app.get('/api/ping', (req, res) => {
  res.status(200).json({
    message: 'Global Ads Launch API is running!',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API routes
app.get('/api', (req, res) => {
  res.json({
    name: 'Global Ads Launch API',
    version: '1.0.0',
    description: 'Production-ready SaaS API for global advertising campaign management',
    endpoints: {
      health: '/health',
      ping: '/api/ping',
      auth: '/api/auth',
      users: '/api/users',
      campaigns: '/api/campaigns',
      analytics: '/api/analytics',
      webhooks: '/api/webhooks',
      feeds: '/api/feeds',
      ads: '/api/ads',
      newCampaigns: '/api/new-campaigns',
      crawler: '/api/crawler'
    }
  });
});

// Auth routes (simplified for now)
app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, firstName, lastName, company } = req.body;
    
    // Basic validation
    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Missing required fields'
        }
      });
    }

    // Mock successful registration
    res.status(201).json({
      success: true,
      data: {
        user: {
          id: 'user_' + Date.now(),
          email,
          firstName,
          lastName,
          company: company || ''
        },
        tokens: {
          accessToken: 'mock_access_token_' + Date.now(),
          refreshToken: 'mock_refresh_token_' + Date.now()
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: {
        message: 'Internal server error'
      }
    });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: {
          message: 'Email and password are required'
        }
      });
    }

    // Mock successful login
    res.status(200).json({
      success: true,
      data: {
        user: {
          id: 'user_' + Date.now(),
          email,
          firstName: 'Test',
          lastName: 'User'
        },
        tokens: {
          accessToken: 'mock_access_token_' + Date.now(),
          refreshToken: 'mock_refresh_token_' + Date.now()
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: {
        message: 'Internal server error'
      }
    });
  }
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: {
      message: 'Route not found'
    }
  });
});

// Error handler
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({
    success: false,
    error: {
      message: 'Internal server error'
    }
  });
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running on port ${port}`);
  console.log(`📊 Health check: http://localhost:${port}/health`);
  console.log(`🔗 API docs: http://localhost:${port}/api`);
});

module.exports = app;