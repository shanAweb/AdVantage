"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const compression_1 = __importDefault(require("compression"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const dotenv_1 = __importDefault(require("dotenv"));
const errorHandler_1 = require("@/middleware/errorHandler");
const notFoundHandler_1 = require("@/middleware/notFoundHandler");
const logger_1 = require("@/utils/logger");
const database_1 = require("@/config/database");
const redis_1 = require("@/config/redis");
const feedCrawlerWorker_1 = require("@/workers/feedCrawlerWorker");
const auth_1 = __importDefault(require("@/routes/auth"));
const users_1 = __importDefault(require("@/routes/users"));
const campaigns_1 = __importDefault(require("@/routes/campaigns"));
const analytics_1 = __importDefault(require("@/routes/analytics"));
const webhooks_1 = __importDefault(require("@/routes/webhooks"));
const feeds_1 = __importDefault(require("@/routes/feeds"));
const ads_1 = __importDefault(require("@/routes/ads"));
const newCampaigns_1 = __importDefault(require("@/routes/newCampaigns"));
dotenv_1.default.config();
class Server {
    constructor() {
        this.app = (0, express_1.default)();
        // this.port = parseInt(process.env.PORT || '5000', 10);
        this.port = parseInt(process.env.PORT, 10);
        this.initializeMiddleware();
        this.initializeRoutes();
        this.initializeErrorHandling();
    }
    initializeMiddleware() {
        this.app.use((0, helmet_1.default)({
            contentSecurityPolicy: {
                directives: {
                    defaultSrc: ["'self'"],
                    styleSrc: ["'self'", "'unsafe-inline'"],
                    scriptSrc: ["'self'"],
                    imgSrc: ["'self'", "data:", "https:"],
                },
            },
        }));
        this.app.use((0, cors_1.default)({
            origin: process.env.FRONTEND_URL || ["http://localhost:3000", "http://localhost:3001"],
            credentials: true,
            methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
            allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
        }));
        const limiter = (0, express_rate_limit_1.default)({
            windowMs: 15 * 60 * 1000,
            max: 100,
            message: 'Too many requests from this IP, please try again later.',
            standardHeaders: true,
            legacyHeaders: false,
        });
        this.app.use('/api/', limiter);
        this.app.use(express_1.default.json({ limit: '10mb' }));
        this.app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
        this.app.use((0, compression_1.default)());
        this.app.use((0, morgan_1.default)('combined', {
            stream: {
                write: (message) => logger_1.logger.info(message.trim())
            }
        }));
        this.app.get('/health', (req, res) => {
            res.status(200).json({
                status: 'OK',
                timestamp: new Date().toISOString(),
                uptime: process.uptime(),
                environment: process.env.NODE_ENV || 'development'
            });
        });
        this.app.get('/api/ping', (req, res) => {
            res.status(200).json({
                message: 'Global Ads Launch API is running!',
                timestamp: new Date().toISOString(),
                version: process.env.npm_package_version || '1.0.0'
            });
        });
    }
    initializeRoutes() {
        this.app.use('/api/auth', auth_1.default);
        this.app.use('/api/users', users_1.default);
        this.app.use('/api/campaigns', campaigns_1.default);
        this.app.use('/api/analytics', analytics_1.default);
        this.app.use('/api/webhooks', webhooks_1.default);
        this.app.use('/api/feeds', feeds_1.default);
        this.app.use('/api/ads', ads_1.default);
        this.app.use('/api/new-campaigns', newCampaigns_1.default);
        this.app.get('/api', (req, res) => {
            res.json({
                name: 'Global Ads Launch API',
                version: '1.0.0',
                description: 'Production-ready SaaS API for global advertising campaign management',
                endpoints: {
                    health: '/health',
                    ping: '/api/ping',
                    auth: '/api/auth',
                    users: '/api/users',
                    campaigns: '/api/campaigns',
                    analytics: '/api/analytics',
                    webhooks: '/api/webhooks',
                    feeds: '/api/feeds',
                    ads: '/api/ads',
                    newCampaigns: '/api/new-campaigns'
                },
                documentation: 'https://docs.globaladslaunch.com'
            });
        });
    }
    initializeErrorHandling() {
        this.app.use(notFoundHandler_1.notFoundHandler);
        this.app.use(errorHandler_1.errorHandler);
    }
    async start() {
        try {
            await (0, database_1.connectDatabase)();
            logger_1.logger.info('Database connected successfully');
            await (0, redis_1.connectRedis)();
            logger_1.logger.info('Redis connection attempted');
            (0, feedCrawlerWorker_1.initializeFeedCrawlerWorker)();
            logger_1.logger.info('Workers initialized successfully');
            this.app.listen(this.port, () => {
                logger_1.logger.info(`🚀 Server running on port ${this.port}`);
                logger_1.logger.info(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
                logger_1.logger.info(`🌐 API URL: http://localhost:${this.port}/api`);
                logger_1.logger.info(`❤️  Health check: http://localhost:${this.port}/health`);
            });
        }
        catch (error) {
            logger_1.logger.error('Failed to start server:', error);
            process.exit(1);
        }
    }
    async shutdown() {
        logger_1.logger.info('Shutting down server...');
        process.exit(0);
    }
}
process.on('uncaughtException', (error) => {
    logger_1.logger.error('Uncaught Exception:', error);
    process.exit(1);
});
process.on('unhandledRejection', (reason, promise) => {
    logger_1.logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});
process.on('SIGTERM', () => {
    logger_1.logger.info('SIGTERM received, shutting down gracefully');
    process.exit(0);
});
process.on('SIGINT', () => {
    logger_1.logger.info('SIGINT received, shutting down gracefully');
    process.exit(0);
});
const server = new Server();
server.start();
exports.default = server;
//# sourceMappingURL=server.js.map