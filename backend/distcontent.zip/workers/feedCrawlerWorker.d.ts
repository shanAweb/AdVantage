export declare function initializeFeedCrawlerWorker(): void;
declare const _default: {
    initializeFeedCrawlerWorker: typeof initializeFeedCrawlerWorker;
};
export default _default;
//# sourceMappingURL=feedCrawlerWorker.d.ts.map