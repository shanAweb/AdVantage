"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeFeedCrawlerWorker = initializeFeedCrawlerWorker;
const queue_1 = require("@/config/queue");
const feedCrawler_1 = require("@/services/feedCrawler");
const logger_1 = require("@/utils/logger");
let workerInitialized = false;
function initializeFeedCrawlerWorker() {
    if (workerInitialized) {
        return;
    }
    try {
        const feedCrawlQueue = (0, queue_1.getFeedCrawlQueue)();
        if (feedCrawlQueue) {
            feedCrawlQueue.process('crawl-feed', async (job) => {
                try {
                    const { feedId } = job.data;
                    logger_1.logger.info(`Processing feed crawl job for feed ${feedId}`);
                    await feedCrawler_1.feedCrawlerService.crawlFeed(feedId);
                    logger_1.logger.info(`Feed crawl job completed for feed ${feedId}`);
                    return { success: true, feedId };
                }
                catch (error) {
                    logger_1.logger.error(`Feed crawl job failed:`, error);
                    throw error;
                }
            });
            feedCrawlQueue.on('completed', (job, result) => {
                logger_1.logger.info(`Feed crawl job ${job.id} completed:`, result);
            });
            feedCrawlQueue.on('failed', (job, err) => {
                logger_1.logger.error(`Feed crawl job ${job?.id} failed:`, err);
            });
            feedCrawlQueue.on('stalled', (job) => {
                logger_1.logger.warn(`Feed crawl job ${job.id} stalled`);
            });
            logger_1.logger.info('✅ Feed crawler worker initialized with Redis');
        }
        else {
            logger_1.logger.info('⚠️  Feed crawler worker disabled - Redis not available');
        }
        workerInitialized = true;
    }
    catch (error) {
        logger_1.logger.error('❌ Failed to initialize feed crawler worker:', error);
        throw error;
    }
}
exports.default = { initializeFeedCrawlerWorker };
//# sourceMappingURL=feedCrawlerWorker.js.map