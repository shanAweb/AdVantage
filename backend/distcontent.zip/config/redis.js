"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheService = void 0;
exports.getRedisClient = getRedisClient;
exports.connectRedis = connectRedis;
exports.disconnectRedis = disconnectRedis;
exports.checkRedisHealth = checkRedisHealth;
const redis_1 = require("redis");
const logger_1 = require("@/utils/logger");
let redisClient = null;
function getRedisClient() {
    if (!redisClient) {
        throw new Error('Redis client not initialized. Call connectRedis() first.');
    }
    return redisClient;
}
async function connectRedis() {
    if (!process.env.REDIS_URL) {
        logger_1.logger.info('⚠️  Redis URL not provided - running without Redis');
        return;
    }
    try {
        redisClient = (0, redis_1.createClient)({
            url: process.env.REDIS_URL,
            socket: {
                reconnectStrategy: (retries) => {
                    if (retries > 10) {
                        logger_1.logger.error('Redis connection failed after 10 retries');
                        return new Error('Redis connection failed');
                    }
                    return Math.min(retries * 50, 1000);
                }
            }
        });
        redisClient.on('error', (err) => {
            logger_1.logger.error('Redis client error:', err);
        });
        redisClient.on('connect', () => {
            logger_1.logger.info('✅ Redis client connected');
        });
        redisClient.on('ready', () => {
            logger_1.logger.info('✅ Redis client ready');
        });
        redisClient.on('end', () => {
            logger_1.logger.info('Redis client disconnected');
        });
        await redisClient.connect();
    }
    catch (error) {
        logger_1.logger.error('❌ Redis connection failed:', error);
        logger_1.logger.info('⚠️  Continuing without Redis - some features may be limited');
        redisClient = null;
    }
}
async function disconnectRedis() {
    try {
        if (redisClient) {
            await redisClient.quit();
            redisClient = null;
            logger_1.logger.info('✅ Redis disconnected successfully');
        }
    }
    catch (error) {
        logger_1.logger.error('❌ Redis disconnection failed:', error);
        throw error;
    }
}
async function checkRedisHealth() {
    try {
        if (!redisClient) {
            return false;
        }
        await redisClient.ping();
        return true;
    }
    catch (error) {
        logger_1.logger.error('Redis health check failed:', error);
        return false;
    }
}
class CacheService {
    constructor() {
        this.client = getRedisClient();
    }
    async set(key, value, ttl) {
        try {
            const serializedValue = JSON.stringify(value);
            if (ttl) {
                await this.client.setEx(key, ttl, serializedValue);
            }
            else {
                await this.client.set(key, serializedValue);
            }
        }
        catch (error) {
            logger_1.logger.error('Cache set error:', error);
            throw error;
        }
    }
    async get(key) {
        try {
            const value = await this.client.get(key);
            return value ? JSON.parse(value) : null;
        }
        catch (error) {
            logger_1.logger.error('Cache get error:', error);
            return null;
        }
    }
    async delete(key) {
        try {
            await this.client.del(key);
        }
        catch (error) {
            logger_1.logger.error('Cache delete error:', error);
            throw error;
        }
    }
    async exists(key) {
        try {
            const result = await this.client.exists(key);
            return result === 1;
        }
        catch (error) {
            logger_1.logger.error('Cache exists error:', error);
            return false;
        }
    }
    async expire(key, ttl) {
        try {
            await this.client.expire(key, ttl);
        }
        catch (error) {
            logger_1.logger.error('Cache expire error:', error);
            throw error;
        }
    }
}
exports.CacheService = CacheService;
//# sourceMappingURL=redis.js.map