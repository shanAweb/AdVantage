import Queue from 'bull';
export interface QueueConfig {
    redis: {
        host: string;
        port: number;
        password?: string;
    };
    defaultJobOptions: {
        removeOnComplete: number;
        removeOnFail: number;
        attempts: number;
        backoff: {
            type: string;
            delay: number;
        };
    };
}
export declare function createQueue(name: string, config?: Partial<QueueConfig>): Queue.Queue | null;
export declare function getFeedCrawlQueue(): Queue.Queue | null;
export declare function getCampaignQueue(): Queue.Queue | null;
export declare function getExportQueue(): Queue.Queue | null;
export declare function cleanupQueues(): Promise<void>;
//# sourceMappingURL=queue.d.ts.map