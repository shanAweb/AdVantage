import { RedisClientType } from 'redis';
export declare function getRedisClient(): RedisClientType;
export declare function connectRedis(): Promise<void>;
export declare function disconnectRedis(): Promise<void>;
export declare function checkRedisHealth(): Promise<boolean>;
export declare class CacheService {
    private client;
    constructor();
    set(key: string, value: any, ttl?: number): Promise<void>;
    get(key: string): Promise<any>;
    delete(key: string): Promise<void>;
    exists(key: string): Promise<boolean>;
    expire(key: string, ttl: number): Promise<void>;
}
//# sourceMappingURL=redis.d.ts.map