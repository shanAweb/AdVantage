"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQueue = createQueue;
exports.getFeedCrawlQueue = getFeedCrawlQueue;
exports.getCampaignQueue = getCampaignQueue;
exports.getExportQueue = getExportQueue;
exports.cleanupQueues = cleanupQueues;
const bull_1 = __importDefault(require("bull"));
const redis_1 = require("./redis");
const logger_1 = require("@/utils/logger");
let feedCrawlQueue = null;
let campaignQueue = null;
let exportQueue = null;
function createQueue(name, config) {
    if (!process.env.REDIS_URL) {
        logger_1.logger.info(`⚠️  Queue ${name} disabled - Redis not available`);
        return null;
    }
    try {
        const redisClient = (0, redis_1.getRedisClient)();
        const queueConfig = {
            redis: {
                host: process.env.REDIS_HOST || 'localhost',
                port: parseInt(process.env.REDIS_PORT || '6379'),
                password: process.env.REDIS_PASSWORD,
            },
            defaultJobOptions: {
                removeOnComplete: 10,
                removeOnFail: 5,
                attempts: 3,
                backoff: {
                    type: 'exponential',
                    delay: 2000,
                },
            },
            ...config,
        };
        const queue = new bull_1.default(name, {
            redis: redisClient.options,
            defaultJobOptions: queueConfig.defaultJobOptions,
        });
        queue.on('error', (error) => {
            logger_1.logger.error(`Queue ${name} error:`, error);
        });
        queue.on('waiting', (jobId) => {
            logger_1.logger.info(`Job ${jobId} is waiting in queue ${name}`);
        });
        queue.on('active', (job) => {
            logger_1.logger.info(`Job ${job.id} is now active in queue ${name}`);
        });
        queue.on('completed', (job) => {
            logger_1.logger.info(`Job ${job.id} completed in queue ${name}`);
        });
        queue.on('failed', (job, err) => {
            logger_1.logger.error(`Job ${job?.id} failed in queue ${name}:`, err);
        });
        queue.on('stalled', (job) => {
            logger_1.logger.warn(`Job ${job.id} stalled in queue ${name}`);
        });
        return queue;
    }
    catch (error) {
        logger_1.logger.error(`❌ Failed to create queue ${name}:`, error);
        return null;
    }
}
function getFeedCrawlQueue() {
    if (!feedCrawlQueue) {
        feedCrawlQueue = createQueue('feeds:crawl', {
            defaultJobOptions: {
                removeOnComplete: 5,
                removeOnFail: 3,
                attempts: 2,
                backoff: {
                    type: 'exponential',
                    delay: 5000,
                },
            },
        });
    }
    return feedCrawlQueue;
}
function getCampaignQueue() {
    if (!campaignQueue) {
        campaignQueue = createQueue('campaigns:process', {
            defaultJobOptions: {
                removeOnComplete: 10,
                removeOnFail: 5,
                attempts: 3,
                backoff: {
                    type: 'exponential',
                    delay: 3000,
                },
            },
        });
    }
    return campaignQueue;
}
function getExportQueue() {
    if (!exportQueue) {
        exportQueue = createQueue('feeds:export', {
            defaultJobOptions: {
                removeOnComplete: 20,
                removeOnFail: 10,
                attempts: 2,
                backoff: {
                    type: 'fixed',
                    delay: 1000,
                },
            },
        });
    }
    return exportQueue;
}
async function cleanupQueues() {
    try {
        const queuesToClose = [];
        if (feedCrawlQueue) {
            queuesToClose.push(feedCrawlQueue.close());
        }
        if (campaignQueue) {
            queuesToClose.push(campaignQueue.close());
        }
        if (exportQueue) {
            queuesToClose.push(exportQueue.close());
        }
        if (queuesToClose.length > 0) {
            await Promise.all(queuesToClose);
        }
        logger_1.logger.info('✅ All queues closed successfully');
    }
    catch (error) {
        logger_1.logger.error('❌ Error closing queues:', error);
    }
}
//# sourceMappingURL=queue.js.map