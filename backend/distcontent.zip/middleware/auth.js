"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRateLimit = exports.requirePlan = exports.optionalAuth = exports.authenticate = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("./errorHandler");
const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new errorHandler_1.ApiError('Access token required', 401);
        }
        const token = authHeader.substring(7);
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        const user = await database_1.prisma.user.findUnique({
            where: { id: decoded.userId },
            include: {
                subscription: true
            }
        });
        if (!user) {
            throw new errorHandler_1.ApiError('User not found', 401);
        }
        ;
        req.user = user;
        next();
    }
    catch (error) {
        if (error instanceof jsonwebtoken_1.default.JsonWebTokenError) {
            next(new errorHandler_1.ApiError('Invalid token', 401));
        }
        else if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
            next(new errorHandler_1.ApiError('Token expired', 401));
        }
        else {
            next(error);
        }
    }
};
exports.authenticate = authenticate;
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return next();
        }
        const token = authHeader.substring(7);
        try {
            const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
            const user = await database_1.prisma.user.findUnique({
                where: { id: decoded.userId },
                include: {
                    subscription: true
                }
            });
            if (user) {
                ;
                req.user = user;
            }
        }
        catch (jwtError) {
            logger_1.logger.debug('Optional auth JWT error:', jwtError);
        }
        next();
    }
    catch (error) {
        next(error);
    }
};
exports.optionalAuth = optionalAuth;
const requirePlan = (requiredPlan) => {
    return (req, res, next) => {
        try {
            const user = req.user;
            if (!user) {
                throw new errorHandler_1.ApiError('Authentication required', 401);
            }
            const userPlan = user.subscription?.planId;
            const planHierarchy = {
                free: 0,
                starter: 1,
                professional: 2,
                enterprise: 3
            };
            const userPlanLevel = planHierarchy[userPlan] || 0;
            const requiredPlanLevel = planHierarchy[requiredPlan] || 0;
            if (userPlanLevel < requiredPlanLevel) {
                throw new errorHandler_1.ApiError(`This feature requires ${requiredPlan} plan or higher`, 403);
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
};
exports.requirePlan = requirePlan;
const createRateLimit = (windowMs, maxRequests) => {
    const requests = new Map();
    return (req, res, next) => {
        const userId = req.user?.id || req.ip;
        const now = Date.now();
        const windowStart = now - windowMs;
        for (const [key, timestamp] of requests.entries()) {
            if (timestamp < windowStart) {
                requests.delete(key);
            }
        }
        const userRequests = Array.from(requests.entries())
            .filter(([key, timestamp]) => key.startsWith(userId) && timestamp > windowStart);
        if (userRequests.length >= maxRequests) {
            throw new errorHandler_1.ApiError('Too many requests, please try again later', 429);
        }
        requests.set(`${userId}-${now}`, now);
        next();
    };
};
exports.createRateLimit = createRateLimit;
//# sourceMappingURL=auth.js.map