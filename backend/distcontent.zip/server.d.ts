import express from 'express';
declare class Server {
    app: express.Application;
    private port;
    constructor();
    private initializeMiddleware;
    private initializeRoutes;
    private initializeErrorHandling;
    start(): Promise<void>;
    shutdown(): Promise<void>;
}
declare const server: Server;
export default server;
//# sourceMappingURL=server.d.ts.map