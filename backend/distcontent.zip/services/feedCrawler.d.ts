export interface CrawledProduct {
    title: string;
    description?: string;
    price?: number;
    currency?: string;
    imageUrl?: string;
    link: string;
    availability?: string;
    brand?: string;
    category?: string;
    sku?: string;
    gtin?: string;
    mpn?: string;
    condition?: string;
    rawData?: any;
}
export declare class FeedCrawlerService {
    private readonly maxProducts;
    private readonly timeout;
    crawlFeed(feedId: string): Promise<void>;
    private extractProducts;
    private extractFromJsonLd;
    private parseJsonLdProduct;
    private extractFromSelectors;
    private extractText;
    private extractImageUrl;
    private extractLink;
    private parsePrice;
    private getImageUrl;
}
export declare const feedCrawlerService: FeedCrawlerService;
//# sourceMappingURL=feedCrawler.d.ts.map