import { Product, Feed } from '@prisma/client';
export declare class FeedExportService {
    exportToCSV(products: Product[], feed: Feed): string;
    exportToJSON(products: Product[], feed: Feed): string;
    exportToGoogleXML(products: Product[], feed: Feed): string;
    exportToFacebookXML(products: Product[], feed: Feed): string;
    private escapeCsvField;
    private escapeXml;
    private mapAvailability;
    private mapCondition;
}
export declare const feedExportService: FeedExportService;
//# sourceMappingURL=feedExport.d.ts.map