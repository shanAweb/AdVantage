"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.feedCrawlerService = exports.FeedCrawlerService = void 0;
const axios_1 = __importDefault(require("axios"));
const cheerio = __importStar(require("cheerio"));
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
class FeedCrawlerService {
    constructor() {
        this.maxProducts = 100;
        this.timeout = 30000;
    }
    async crawlFeed(feedId) {
        try {
            logger_1.logger.info(`Starting crawl for feed ${feedId}`);
            const feed = await database_1.prisma.feed.findUnique({
                where: { id: feedId },
            });
            if (!feed) {
                throw new Error(`Feed ${feedId} not found`);
            }
            await database_1.prisma.feed.update({
                where: { id: feedId },
                data: {
                    lastCrawlStatus: 'running',
                    lastCrawlAt: new Date(),
                },
            });
            const products = await this.extractProducts(feed.siteUrl, feed.selectorConfig);
            await database_1.prisma.product.deleteMany({
                where: { feedId },
            });
            if (products.length > 0) {
                await database_1.prisma.product.createMany({
                    data: products.map(product => ({
                        feedId,
                        title: product.title,
                        description: product.description,
                        price: product.price,
                        currency: product.currency || feed.currency || 'USD',
                        imageUrl: product.imageUrl,
                        link: product.link,
                        availability: product.availability,
                        brand: product.brand,
                        category: product.category,
                        sku: product.sku,
                        gtin: product.gtin,
                        mpn: product.mpn,
                        condition: product.condition,
                        rawData: product.rawData,
                    })),
                });
                logger_1.logger.info(`Crawled ${products.length} products for feed ${feedId}`);
            }
            await database_1.prisma.feed.update({
                where: { id: feedId },
                data: {
                    lastCrawlStatus: 'completed',
                    lastCrawlAt: new Date(),
                },
            });
        }
        catch (error) {
            logger_1.logger.error(`Crawl failed for feed ${feedId}:`, error);
            await database_1.prisma.feed.update({
                where: { id: feedId },
                data: {
                    lastCrawlStatus: 'failed',
                    lastCrawlAt: new Date(),
                },
            });
            throw error;
        }
    }
    async extractProducts(siteUrl, selectorConfig) {
        try {
            const response = await axios_1.default.get(siteUrl, {
                timeout: this.timeout,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                },
            });
            const $ = cheerio.load(response.data);
            const products = [];
            const jsonLdProducts = this.extractFromJsonLd($);
            if (jsonLdProducts.length > 0) {
                products.push(...jsonLdProducts.slice(0, this.maxProducts));
                logger_1.logger.info(`Extracted ${jsonLdProducts.length} products from JSON-LD`);
                return products;
            }
            const selectorProducts = this.extractFromSelectors($, selectorConfig);
            products.push(...selectorProducts.slice(0, this.maxProducts));
            logger_1.logger.info(`Extracted ${products.length} products from selectors`);
            return products;
        }
        catch (error) {
            logger_1.logger.error(`Error extracting products from ${siteUrl}:`, error);
            throw error;
        }
    }
    extractFromJsonLd($) {
        const products = [];
        $('script[type="application/ld+json"]').each((_, element) => {
            try {
                const jsonData = JSON.parse($(element).html() || '{}');
                if (jsonData['@type'] === 'Product') {
                    products.push(this.parseJsonLdProduct(jsonData));
                }
                else if (Array.isArray(jsonData)) {
                    jsonData.forEach(item => {
                        if (item['@type'] === 'Product') {
                            products.push(this.parseJsonLdProduct(item));
                        }
                    });
                }
                else if (jsonData['@type'] === 'ItemList' && Array.isArray(jsonData.itemListElement)) {
                    jsonData.itemListElement.forEach((item) => {
                        if (item.item && item.item['@type'] === 'Product') {
                            products.push(this.parseJsonLdProduct(item.item));
                        }
                    });
                }
            }
            catch (error) {
                logger_1.logger.warn('Error parsing JSON-LD:', error);
            }
        });
        return products;
    }
    parseJsonLdProduct(jsonData) {
        return {
            title: jsonData.name || '',
            description: jsonData.description || '',
            price: this.parsePrice(jsonData.offers?.price || jsonData.price),
            currency: jsonData.offers?.priceCurrency || jsonData.priceCurrency || 'USD',
            imageUrl: this.getImageUrl(jsonData.image),
            link: jsonData.url || '',
            availability: jsonData.offers?.availability || 'in_stock',
            brand: jsonData.brand?.name || jsonData.brand,
            category: jsonData.category,
            sku: jsonData.sku,
            gtin: jsonData.gtin,
            mpn: jsonData.mpn,
            condition: jsonData.condition,
            rawData: jsonData,
        };
    }
    extractFromSelectors($, selectorConfig) {
        const products = [];
        const defaultSelectors = {
            productContainer: '.product, .item, [data-product], .product-item',
            title: 'h1, h2, h3, .title, .name, .product-title',
            description: '.description, .summary, .excerpt',
            price: '.price, .cost, .amount, [data-price]',
            image: 'img',
            link: 'a',
        };
        const selectors = { ...defaultSelectors, ...selectorConfig };
        $(selectors.productContainer).each((_, element) => {
            try {
                const $product = $(element);
                const product = {
                    title: this.extractText($product, selectors.title),
                    description: this.extractText($product, selectors.description),
                    price: this.parsePrice(this.extractText($product, selectors.price)),
                    imageUrl: this.extractImageUrl($product, selectors.image),
                    link: this.extractLink($product, selectors.link),
                    availability: 'in_stock',
                };
                if (product.title && product.link) {
                    products.push(product);
                }
            }
            catch (error) {
                logger_1.logger.warn('Error extracting product from selector:', error);
            }
        });
        return products;
    }
    extractText($parent, selector) {
        return $parent.find(selector).first().text().trim();
    }
    extractImageUrl($parent, selector) {
        const $img = $parent.find(selector).first();
        return $img.attr('src') || $img.attr('data-src') || '';
    }
    extractLink($parent, selector) {
        const $link = $parent.find(selector).first();
        return $link.attr('href') || '';
    }
    parsePrice(priceStr) {
        if (typeof priceStr === 'number')
            return priceStr;
        if (!priceStr)
            return undefined;
        const cleaned = priceStr.toString().replace(/[^\d.,]/g, '');
        const parsed = parseFloat(cleaned.replace(',', '.'));
        return isNaN(parsed) ? undefined : parsed;
    }
    getImageUrl(imageData) {
        if (typeof imageData === 'string') {
            return imageData;
        }
        if (Array.isArray(imageData) && imageData.length > 0) {
            return imageData[0];
        }
        if (imageData && imageData.url) {
            return imageData.url;
        }
        return '';
    }
}
exports.FeedCrawlerService = FeedCrawlerService;
exports.feedCrawlerService = new FeedCrawlerService();
//# sourceMappingURL=feedCrawler.js.map