"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const feedController_1 = require("@/controllers/feedController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.post('/', [
    auth_1.authenticate,
    (0, express_validator_1.body)('name').notEmpty().withMessage('Feed name is required'),
    (0, express_validator_1.body)('siteUrl').isURL().withMessage('Valid site URL is required'),
    (0, express_validator_1.body)('country').optional().isString().withMessage('Country must be a string'),
    (0, express_validator_1.body)('currency').optional().isString().withMessage('Currency must be a string'),
    (0, express_validator_1.body)('selectorConfig').optional().isObject().withMessage('Selector config must be an object'),
    validateRequest_1.validateRequest
], feedController_1.createFeed);
router.get('/', [
    auth_1.authenticate,
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    validateRequest_1.validateRequest
], feedController_1.getFeeds);
router.get('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    validateRequest_1.validateRequest
], feedController_1.getFeed);
router.put('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.body)('name').optional().notEmpty().withMessage('Feed name cannot be empty'),
    (0, express_validator_1.body)('siteUrl').optional().isURL().withMessage('Valid site URL is required'),
    (0, express_validator_1.body)('country').optional().isString().withMessage('Country must be a string'),
    (0, express_validator_1.body)('currency').optional().isString().withMessage('Currency must be a string'),
    (0, express_validator_1.body)('selectorConfig').optional().isObject().withMessage('Selector config must be an object'),
    validateRequest_1.validateRequest
], feedController_1.updateFeed);
router.delete('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    validateRequest_1.validateRequest
], feedController_1.deleteFeed);
router.post('/:id/refresh', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    validateRequest_1.validateRequest
], feedController_1.refreshFeed);
router.get('/:id/products', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('search').optional().isString().withMessage('Search must be a string'),
    validateRequest_1.validateRequest
], feedController_1.getFeedProducts);
router.get('/:id/download', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.query)('format').optional().isIn(['json', 'csv', 'xml', 'facebook']).withMessage('Format must be json, csv, xml, or facebook'),
    validateRequest_1.validateRequest
], feedController_1.downloadFeed);
router.get('/public/:token', [
    (0, express_validator_1.param)('token').isString().withMessage('Public token is required'),
    (0, express_validator_1.query)('format').optional().isIn(['json', 'csv', 'xml', 'facebook']).withMessage('Format must be json, csv, xml, or facebook'),
    validateRequest_1.validateRequest
], feedController_1.getPublicFeed);
exports.default = router;
//# sourceMappingURL=feeds.js.map