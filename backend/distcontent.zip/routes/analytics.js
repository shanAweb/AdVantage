"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const analyticsController_1 = require("@/controllers/analyticsController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.get('/dashboard', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('platform').optional().isIn(['google', 'microsoft', 'youtube', 'all']).withMessage('Platform must be google, microsoft, youtube, or all'),
    validateRequest_1.validateRequest
], analyticsController_1.getDashboardStats);
router.get('/campaigns', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('campaignIds').optional().isArray().withMessage('Campaign IDs must be an array'),
    (0, express_validator_1.query)('platform').optional().isIn(['google', 'microsoft', 'youtube', 'all']).withMessage('Platform must be google, microsoft, youtube, or all'),
    validateRequest_1.validateRequest
], analyticsController_1.getCampaignAnalytics);
router.get('/platforms', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('platform').isIn(['google', 'microsoft', 'youtube']).withMessage('Platform must be google, microsoft, or youtube'),
    validateRequest_1.validateRequest
], analyticsController_1.getPlatformAnalytics);
router.get('/conversions', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('campaignId').optional().isUUID().withMessage('Campaign ID must be a valid UUID'),
    validateRequest_1.validateRequest
], analyticsController_1.getConversionAnalytics);
router.get('/keywords', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('campaignId').optional().isUUID().withMessage('Campaign ID must be a valid UUID'),
    (0, express_validator_1.query)('platform').optional().isIn(['google', 'microsoft', 'youtube']).withMessage('Platform must be google, microsoft, or youtube'),
    validateRequest_1.validateRequest
], analyticsController_1.getKeywordPerformance);
router.get('/audience', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('campaignId').optional().isUUID().withMessage('Campaign ID must be a valid UUID'),
    validateRequest_1.validateRequest
], analyticsController_1.getAudienceInsights);
router.get('/export', [
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    (0, express_validator_1.query)('format').isIn(['csv', 'xlsx', 'json']).withMessage('Format must be csv, xlsx, or json'),
    (0, express_validator_1.query)('type').isIn(['campaigns', 'keywords', 'conversions', 'all']).withMessage('Type must be campaigns, keywords, conversions, or all'),
    validateRequest_1.validateRequest
], analyticsController_1.exportAnalytics);
exports.default = router;
//# sourceMappingURL=analytics.js.map