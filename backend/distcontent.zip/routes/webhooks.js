"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const webhookController_1 = require("@/controllers/webhookController");
const validateRequest_1 = require("@/middleware/validateRequest");
const router = (0, express_1.Router)();
router.post('/stripe', [
    (0, express_validator_1.body)('type').notEmpty().withMessage('Event type is required'),
    (0, express_validator_1.body)('data').notEmpty().withMessage('Event data is required'),
    validateRequest_1.validateRequest
], webhookController_1.stripeWebhook);
router.post('/google-ads', [
    (0, express_validator_1.body)('eventType').notEmpty().withMessage('Event type is required'),
    (0, express_validator_1.body)('resourceName').notEmpty().withMessage('Resource name is required'),
    validateRequest_1.validateRequest
], webhookController_1.googleAdsWebhook);
router.post('/microsoft-ads', [
    (0, express_validator_1.body)('eventType').notEmpty().withMessage('Event type is required'),
    (0, express_validator_1.body)('resourceId').notEmpty().withMessage('Resource ID is required'),
    validateRequest_1.validateRequest
], webhookController_1.microsoftAdsWebhook);
router.post('/youtube', [
    (0, express_validator_1.body)('eventType').notEmpty().withMessage('Event type is required'),
    (0, express_validator_1.body)('videoId').notEmpty().withMessage('Video ID is required'),
    validateRequest_1.validateRequest
], webhookController_1.youtubeWebhook);
exports.default = router;
//# sourceMappingURL=webhooks.js.map