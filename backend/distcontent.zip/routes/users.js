"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const userController_1 = require("@/controllers/userController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.get('/profile', userController_1.getProfile);
router.put('/profile', [
    (0, express_validator_1.body)('firstName').optional().isString().withMessage('First name must be a string'),
    (0, express_validator_1.body)('lastName').optional().isString().withMessage('Last name must be a string'),
    (0, express_validator_1.body)('company').optional().isString().withMessage('Company must be a string'),
    (0, express_validator_1.body)('phone').optional().isString().withMessage('Phone must be a string'),
    (0, express_validator_1.body)('timezone').optional().isString().withMessage('Timezone must be a string'),
    validateRequest_1.validateRequest
], userController_1.updateProfile);
router.put('/change-password', [
    (0, express_validator_1.body)('currentPassword').notEmpty().withMessage('Current password is required'),
    (0, express_validator_1.body)('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
    validateRequest_1.validateRequest
], userController_1.changePassword);
router.get('/stats', userController_1.getUserStats);
router.put('/subscription', [
    (0, express_validator_1.body)('planId').notEmpty().withMessage('Plan ID is required'),
    (0, express_validator_1.body)('paymentMethodId').optional().isString().withMessage('Payment method ID must be a string'),
    validateRequest_1.validateRequest
], userController_1.updateSubscription);
router.delete('/account', userController_1.deleteAccount);
exports.default = router;
//# sourceMappingURL=users.js.map