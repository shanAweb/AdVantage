"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const campaignController_1 = require("@/controllers/campaignController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.post('/', [
    (0, express_validator_1.body)('name').notEmpty().withMessage('Campaign name is required'),
    (0, express_validator_1.body)('platform').isIn(['google', 'microsoft', 'youtube']).withMessage('Platform must be google, microsoft, or youtube'),
    (0, express_validator_1.body)('budget').isNumeric().withMessage('Budget must be a number'),
    (0, express_validator_1.body)('targetAudience').optional().isObject().withMessage('Target audience must be an object'),
    (0, express_validator_1.body)('keywords').optional().isArray().withMessage('Keywords must be an array'),
    (0, express_validator_1.body)('adGroups').optional().isArray().withMessage('Ad groups must be an array'),
    validateRequest_1.validateRequest
], campaignController_1.createCampaign);
router.get('/', [
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('platform').optional().isIn(['google', 'microsoft', 'youtube']).withMessage('Platform must be google, microsoft, or youtube'),
    (0, express_validator_1.query)('status').optional().isIn(['draft', 'active', 'paused', 'completed']).withMessage('Status must be draft, active, paused, or completed'),
    validateRequest_1.validateRequest
], campaignController_1.getCampaigns);
router.get('/:id', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    validateRequest_1.validateRequest
], campaignController_1.getCampaign);
router.put('/:id', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    (0, express_validator_1.body)('name').optional().notEmpty().withMessage('Campaign name cannot be empty'),
    (0, express_validator_1.body)('budget').optional().isNumeric().withMessage('Budget must be a number'),
    (0, express_validator_1.body)('targetAudience').optional().isObject().withMessage('Target audience must be an object'),
    (0, express_validator_1.body)('keywords').optional().isArray().withMessage('Keywords must be an array'),
    validateRequest_1.validateRequest
], campaignController_1.updateCampaign);
router.delete('/:id', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    validateRequest_1.validateRequest
], campaignController_1.deleteCampaign);
router.post('/:id/launch', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    validateRequest_1.validateRequest
], campaignController_1.launchCampaign);
router.post('/:id/pause', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    validateRequest_1.validateRequest
], campaignController_1.pauseCampaign);
router.post('/:id/resume', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    validateRequest_1.validateRequest
], campaignController_1.resumeCampaign);
router.get('/:id/performance', [
    (0, express_validator_1.param)('id').isUUID().withMessage('Invalid campaign ID'),
    (0, express_validator_1.query)('startDate').optional().isISO8601().withMessage('Start date must be a valid ISO date'),
    (0, express_validator_1.query)('endDate').optional().isISO8601().withMessage('End date must be a valid ISO date'),
    validateRequest_1.validateRequest
], campaignController_1.getCampaignPerformance);
exports.default = router;
//# sourceMappingURL=campaigns.js.map