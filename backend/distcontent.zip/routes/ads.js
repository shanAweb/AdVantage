"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const adController_1 = require("@/controllers/adController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.post('/', [
    auth_1.authenticate,
    (0, express_validator_1.body)('feedId').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.body)('productId').isString().withMessage('Product ID is required'),
    (0, express_validator_1.body)('headline').optional().isString().withMessage('Headline must be a string'),
    (0, express_validator_1.body)('description').optional().isString().withMessage('Description must be a string'),
    validateRequest_1.validateRequest
], adController_1.createAd);
router.post('/bulk', [
    auth_1.authenticate,
    (0, express_validator_1.body)('feedId').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.body)('productIds').isArray({ min: 1 }).withMessage('Product IDs array is required'),
    (0, express_validator_1.body)('productIds.*').isString().withMessage('Each product ID must be a string'),
    (0, express_validator_1.body)('headlineTemplate').optional().isString().withMessage('Headline template must be a string'),
    (0, express_validator_1.body)('descriptionTemplate').optional().isString().withMessage('Description template must be a string'),
    validateRequest_1.validateRequest
], adController_1.bulkCreateAds);
router.get('/', [
    auth_1.authenticate,
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('feedId').optional().isString().withMessage('Feed ID must be a string'),
    (0, express_validator_1.query)('search').optional().isString().withMessage('Search must be a string'),
    validateRequest_1.validateRequest
], adController_1.getAds);
router.get('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Ad ID is required'),
    validateRequest_1.validateRequest
], adController_1.getAd);
router.put('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Ad ID is required'),
    (0, express_validator_1.body)('headline').optional().notEmpty().withMessage('Headline cannot be empty'),
    (0, express_validator_1.body)('description').optional().isString().withMessage('Description must be a string'),
    (0, express_validator_1.body)('finalUrl').optional().isURL().withMessage('Final URL must be a valid URL'),
    (0, express_validator_1.body)('imageUrl').optional().isURL().withMessage('Image URL must be a valid URL'),
    validateRequest_1.validateRequest
], adController_1.updateAd);
router.delete('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Ad ID is required'),
    validateRequest_1.validateRequest
], adController_1.deleteAd);
exports.default = router;
//# sourceMappingURL=ads.js.map