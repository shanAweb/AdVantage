"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const newCampaignController_1 = require("@/controllers/newCampaignController");
const validateRequest_1 = require("@/middleware/validateRequest");
const auth_1 = require("@/middleware/auth");
const router = (0, express_1.Router)();
router.post('/', [
    auth_1.authenticate,
    (0, express_validator_1.body)('feedId').isString().withMessage('Feed ID is required'),
    (0, express_validator_1.body)('name').notEmpty().withMessage('Campaign name is required'),
    (0, express_validator_1.body)('channel').isIn(['google', 'facebook', 'linkedin', 'microsoft']).withMessage('Channel must be google, facebook, linkedin, or microsoft'),
    (0, express_validator_1.body)('budget').isFloat({ min: 0 }).withMessage('Budget must be a positive number'),
    (0, express_validator_1.body)('currency').optional().isString().withMessage('Currency must be a string'),
    (0, express_validator_1.body)('country').notEmpty().withMessage('Country is required'),
    (0, express_validator_1.body)('adIds').optional().isArray().withMessage('Ad IDs must be an array'),
    (0, express_validator_1.body)('adIds.*').optional().isString().withMessage('Each ad ID must be a string'),
    validateRequest_1.validateRequest
], newCampaignController_1.createCampaign);
router.get('/', [
    auth_1.authenticate,
    (0, express_validator_1.query)('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    (0, express_validator_1.query)('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    (0, express_validator_1.query)('feedId').optional().isString().withMessage('Feed ID must be a string'),
    (0, express_validator_1.query)('status').optional().isIn(['draft', 'active', 'paused', 'completed']).withMessage('Status must be draft, active, paused, or completed'),
    (0, express_validator_1.query)('channel').optional().isIn(['google', 'facebook', 'linkedin', 'microsoft']).withMessage('Channel must be google, facebook, linkedin, or microsoft'),
    validateRequest_1.validateRequest
], newCampaignController_1.getCampaigns);
router.get('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    validateRequest_1.validateRequest
], newCampaignController_1.getCampaign);
router.put('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    (0, express_validator_1.body)('name').optional().notEmpty().withMessage('Campaign name cannot be empty'),
    (0, express_validator_1.body)('channel').optional().isIn(['google', 'facebook', 'linkedin', 'microsoft']).withMessage('Channel must be google, facebook, linkedin, or microsoft'),
    (0, express_validator_1.body)('budget').optional().isFloat({ min: 0 }).withMessage('Budget must be a positive number'),
    (0, express_validator_1.body)('currency').optional().isString().withMessage('Currency must be a string'),
    (0, express_validator_1.body)('country').optional().notEmpty().withMessage('Country cannot be empty'),
    (0, express_validator_1.body)('status').optional().isIn(['draft', 'active', 'paused', 'completed']).withMessage('Status must be draft, active, paused, or completed'),
    validateRequest_1.validateRequest
], newCampaignController_1.updateCampaign);
router.delete('/:id', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    validateRequest_1.validateRequest
], newCampaignController_1.deleteCampaign);
router.post('/:id/ads', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    (0, express_validator_1.body)('adIds').isArray({ min: 1 }).withMessage('Ad IDs array is required'),
    (0, express_validator_1.body)('adIds.*').isString().withMessage('Each ad ID must be a string'),
    validateRequest_1.validateRequest
], newCampaignController_1.addAdsToCampaign);
router.delete('/:id/ads', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    (0, express_validator_1.body)('adIds').isArray({ min: 1 }).withMessage('Ad IDs array is required'),
    (0, express_validator_1.body)('adIds.*').isString().withMessage('Each ad ID must be a string'),
    validateRequest_1.validateRequest
], newCampaignController_1.removeAdsFromCampaign);
router.post('/:id/launch', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    validateRequest_1.validateRequest
], newCampaignController_1.launchCampaign);
router.post('/:id/pause', [
    auth_1.authenticate,
    (0, express_validator_1.param)('id').isString().withMessage('Campaign ID is required'),
    validateRequest_1.validateRequest
], newCampaignController_1.pauseCampaign);
exports.default = router;
//# sourceMappingURL=newCampaigns.js.map