"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPublicFeed = exports.downloadFeed = exports.getFeedProducts = exports.refreshFeed = exports.deleteFeed = exports.updateFeed = exports.getFeed = exports.getFeeds = exports.createFeed = void 0;
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const queue_1 = require("@/config/queue");
const feedExport_1 = require("@/services/feedExport");
const feedCrawler_1 = require("@/services/feedCrawler");
const createFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { name, siteUrl, country, currency, selectorConfig } = req.body;
        try {
            new URL(siteUrl);
        }
        catch {
            throw new errorHandler_1.ApiError('Invalid site URL', 400);
        }
        const feed = await database_1.prisma.feed.create({
            data: {
                userId,
                name,
                siteUrl,
                country,
                currency: currency || 'USD',
                selectorConfig,
            },
        });
        const crawlQueue = (0, queue_1.getFeedCrawlQueue)();
        if (crawlQueue) {
            await crawlQueue.add('crawl-feed', { feedId: feed.id });
            logger_1.logger.info('Feed created and queued for crawling', { feedId: feed.id, userId, siteUrl });
        }
        else {
            try {
                await feedCrawler_1.feedCrawlerService.crawlFeed(feed.id);
                logger_1.logger.info('Feed created and crawled immediately', { feedId: feed.id, userId, siteUrl });
            }
            catch (error) {
                logger_1.logger.error('Failed to crawl feed immediately:', error);
            }
        }
        res.status(201).json({
            success: true,
            message: 'Feed created successfully',
            data: { feed }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createFeed = createFeed;
const getFeeds = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 1, limit = 10 } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const [feeds, total] = await Promise.all([
            database_1.prisma.feed.findMany({
                where: { userId },
                skip,
                take,
                orderBy: { createdAt: 'desc' },
                include: {
                    _count: {
                        select: {
                            products: true,
                            ads: true,
                            campaigns: true,
                        }
                    }
                }
            }),
            database_1.prisma.feed.count({ where: { userId } })
        ]);
        res.json({
            success: true,
            data: {
                feeds,
                pagination: {
                    page: Number(page),
                    limit: Number(limit),
                    total,
                    pages: Math.ceil(total / Number(limit))
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getFeeds = getFeeds;
const getFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId },
            include: {
                _count: {
                    select: {
                        products: true,
                        ads: true,
                        campaigns: true,
                    }
                }
            }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        res.json({
            success: true,
            data: { feed }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getFeed = getFeed;
const updateFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const updateData = req.body;
        if (updateData.siteUrl) {
            try {
                new URL(updateData.siteUrl);
            }
            catch {
                throw new errorHandler_1.ApiError('Invalid site URL', 400);
            }
        }
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const updatedFeed = await database_1.prisma.feed.update({
            where: { id },
            data: updateData
        });
        logger_1.logger.info('Feed updated', { feedId: id, userId, updatedFields: Object.keys(updateData) });
        res.json({
            success: true,
            message: 'Feed updated successfully',
            data: { feed: updatedFeed }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateFeed = updateFeed;
const deleteFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        await database_1.prisma.feed.delete({
            where: { id }
        });
        logger_1.logger.info('Feed deleted', { feedId: id, userId });
        res.json({
            success: true,
            message: 'Feed deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteFeed = deleteFeed;
const refreshFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const crawlQueue = (0, queue_1.getFeedCrawlQueue)();
        if (crawlQueue) {
            await crawlQueue.add('crawl-feed', { feedId: feed.id });
            logger_1.logger.info('Feed refresh queued', { feedId: id, userId });
        }
        else {
            try {
                await feedCrawler_1.feedCrawlerService.crawlFeed(feed.id);
                logger_1.logger.info('Feed refreshed immediately', { feedId: id, userId });
            }
            catch (error) {
                logger_1.logger.error('Failed to refresh feed immediately:', error);
            }
        }
        res.json({
            success: true,
            message: 'Feed refresh queued successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.refreshFeed = refreshFeed;
const getFeedProducts = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { page = 1, limit = 20, search } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const where = { feedId: id };
        if (search) {
            where.title = {
                contains: search,
                mode: 'insensitive'
            };
        }
        const [products, total] = await Promise.all([
            database_1.prisma.product.findMany({
                where,
                skip,
                take,
                orderBy: { createdAt: 'desc' },
                include: {
                    _count: {
                        select: {
                            ads: true
                        }
                    }
                }
            }),
            database_1.prisma.product.count({ where })
        ]);
        res.json({
            success: true,
            data: {
                products,
                pagination: {
                    page: Number(page),
                    limit: Number(limit),
                    total,
                    pages: Math.ceil(total / Number(limit))
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getFeedProducts = getFeedProducts;
const downloadFeed = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { format = 'json' } = req.query;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const products = await database_1.prisma.product.findMany({
            where: { feedId: id },
            orderBy: { createdAt: 'desc' }
        });
        let content;
        let contentType;
        let filename;
        switch (format) {
            case 'csv':
                content = feedExport_1.feedExportService.exportToCSV(products, feed);
                contentType = 'text/csv';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.csv`;
                break;
            case 'xml':
                content = feedExport_1.feedExportService.exportToGoogleXML(products, feed);
                contentType = 'application/xml';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.xml`;
                break;
            case 'facebook':
                content = feedExport_1.feedExportService.exportToFacebookXML(products, feed);
                contentType = 'application/xml';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_facebook.xml`;
                break;
            case 'json':
            default:
                content = feedExport_1.feedExportService.exportToJSON(products, feed);
                contentType = 'application/json';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.json`;
                break;
        }
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(content);
        logger_1.logger.info('Feed downloaded', { feedId: id, userId, format, productCount: products.length });
    }
    catch (error) {
        next(error);
    }
};
exports.downloadFeed = downloadFeed;
const getPublicFeed = async (req, res, next) => {
    try {
        const { token } = req.params;
        const { format = 'json' } = req.query;
        const feed = await database_1.prisma.feed.findUnique({
            where: { publicToken: token }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const products = await database_1.prisma.product.findMany({
            where: { feedId: feed.id },
            orderBy: { createdAt: 'desc' }
        });
        let content;
        let contentType;
        let filename;
        switch (format) {
            case 'csv':
                content = feedExport_1.feedExportService.exportToCSV(products, feed);
                contentType = 'text/csv';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.csv`;
                break;
            case 'xml':
                content = feedExport_1.feedExportService.exportToGoogleXML(products, feed);
                contentType = 'application/xml';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.xml`;
                break;
            case 'facebook':
                content = feedExport_1.feedExportService.exportToFacebookXML(products, feed);
                contentType = 'application/xml';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_facebook.xml`;
                break;
            case 'json':
            default:
                content = feedExport_1.feedExportService.exportToJSON(products, feed);
                contentType = 'application/json';
                filename = `${feed.name.replace(/[^a-zA-Z0-9]/g, '_')}_products.json`;
                break;
        }
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.send(content);
        logger_1.logger.info('Public feed accessed', { feedId: feed.id, token, format, productCount: products.length });
    }
    catch (error) {
        next(error);
    }
};
exports.getPublicFeed = getPublicFeed;
//# sourceMappingURL=feedController.js.map