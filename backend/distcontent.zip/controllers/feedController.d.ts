import { Request, Response, NextFunction } from 'express';
export declare const createFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getFeeds: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const updateFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const deleteFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const refreshFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getFeedProducts: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const downloadFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getPublicFeed: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=feedController.d.ts.map