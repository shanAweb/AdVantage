"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resetPassword = exports.forgotPassword = exports.refreshToken = exports.logout = exports.login = exports.register = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const register = async (req, res, next) => {
    try {
        const { email, password, firstName, lastName, company } = req.body;
        const existingUser = await database_1.prisma.user.findUnique({
            where: { email }
        });
        if (existingUser) {
            throw new errorHandler_1.ApiError('User already exists with this email', 400);
        }
        const saltRounds = 12;
        const hashedPassword = await bcryptjs_1.default.hash(password, saltRounds);
        const user = await database_1.prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                firstName,
                lastName,
                company,
                subscription: {
                    create: {
                        planId: 'free',
                        status: 'active',
                        currentPeriodStart: new Date(),
                        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
                    }
                }
            },
            include: {
                subscription: true
            }
        });
        const accessToken = jsonwebtoken_1.default.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '15m' });
        const refreshToken = jsonwebtoken_1.default.sign({ userId: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
        await database_1.prisma.refreshToken.create({
            data: {
                token: refreshToken,
                userId: user.id,
                expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
            }
        });
        logger_1.logger.info('User registered successfully', { userId: user.id, email: user.email });
        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    company: user.company,
                    subscription: user.subscription
                },
                tokens: {
                    accessToken,
                    refreshToken
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.register = register;
const login = async (req, res, next) => {
    try {
        const { email, password } = req.body;
        const user = await database_1.prisma.user.findUnique({
            where: { email },
            include: {
                subscription: true
            }
        });
        if (!user) {
            throw new errorHandler_1.ApiError('Invalid credentials', 401);
        }
        const isPasswordValid = await bcryptjs_1.default.compare(password, user.password);
        if (!isPasswordValid) {
            throw new errorHandler_1.ApiError('Invalid credentials', 401);
        }
        const accessToken = jsonwebtoken_1.default.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '15m' });
        const refreshToken = jsonwebtoken_1.default.sign({ userId: user.id }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
        await database_1.prisma.refreshToken.create({
            data: {
                token: refreshToken,
                userId: user.id,
                expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
            }
        });
        logger_1.logger.info('User logged in successfully', { userId: user.id, email: user.email });
        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    company: user.company,
                    subscription: user.subscription
                },
                tokens: {
                    accessToken,
                    refreshToken
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.login = login;
const logout = async (req, res, next) => {
    try {
        const { refreshToken } = req.body;
        const userId = req.user.id;
        if (refreshToken) {
            await database_1.prisma.refreshToken.deleteMany({
                where: {
                    token: refreshToken,
                    userId
                }
            });
        }
        logger_1.logger.info('User logged out successfully', { userId });
        res.json({
            success: true,
            message: 'Logout successful'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.logout = logout;
const refreshToken = async (req, res, next) => {
    try {
        const { refreshToken } = req.body;
        const decoded = jsonwebtoken_1.default.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
        const tokenRecord = await database_1.prisma.refreshToken.findFirst({
            where: {
                token: refreshToken,
                userId: decoded.userId,
                expiresAt: {
                    gt: new Date()
                }
            }
        });
        if (!tokenRecord) {
            throw new errorHandler_1.ApiError('Invalid refresh token', 401);
        }
        const user = await database_1.prisma.user.findUnique({
            where: { id: decoded.userId },
            include: {
                subscription: true
            }
        });
        if (!user) {
            throw new errorHandler_1.ApiError('User not found', 404);
        }
        const accessToken = jsonwebtoken_1.default.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '15m' });
        res.json({
            success: true,
            message: 'Token refreshed successfully',
            data: {
                accessToken
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.refreshToken = refreshToken;
const forgotPassword = async (req, res, next) => {
    try {
        const { email } = req.body;
        const user = await database_1.prisma.user.findUnique({
            where: { email }
        });
        if (!user) {
            res.json({
                success: true,
                message: 'If an account with that email exists, we sent a password reset link.'
            });
            return;
        }
        const resetToken = jsonwebtoken_1.default.sign({ userId: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        await database_1.prisma.passwordReset.create({
            data: {
                token: resetToken,
                userId: user.id,
                expiresAt: new Date(Date.now() + 60 * 60 * 1000)
            }
        });
        logger_1.logger.info('Password reset token generated', { userId: user.id, email: user.email });
        res.json({
            success: true,
            message: 'If an account with that email exists, we sent a password reset link.'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.forgotPassword = forgotPassword;
const resetPassword = async (req, res, next) => {
    try {
        const { token, password } = req.body;
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        const resetRecord = await database_1.prisma.passwordReset.findFirst({
            where: {
                token,
                userId: decoded.userId,
                expiresAt: {
                    gt: new Date()
                }
            }
        });
        if (!resetRecord) {
            throw new errorHandler_1.ApiError('Invalid or expired reset token', 400);
        }
        const saltRounds = 12;
        const hashedPassword = await bcryptjs_1.default.hash(password, saltRounds);
        await database_1.prisma.user.update({
            where: { id: decoded.userId },
            data: { password: hashedPassword }
        });
        await database_1.prisma.passwordReset.delete({
            where: { id: resetRecord.id }
        });
        await database_1.prisma.refreshToken.deleteMany({
            where: { userId: decoded.userId }
        });
        logger_1.logger.info('Password reset successfully', { userId: decoded.userId });
        res.json({
            success: true,
            message: 'Password reset successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.resetPassword = resetPassword;
//# sourceMappingURL=authController.js.map