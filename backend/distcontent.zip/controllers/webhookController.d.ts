import { Request, Response, NextFunction } from 'express';
export declare const stripeWebhook: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const googleAdsWebhook: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const microsoftAdsWebhook: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const youtubeWebhook: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=webhookController.d.ts.map