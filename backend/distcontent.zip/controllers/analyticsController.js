"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exportAnalytics = exports.getAudienceInsights = exports.getKeywordPerformance = exports.getConversionAnalytics = exports.getPlatformAnalytics = exports.getCampaignAnalytics = exports.getDashboardStats = void 0;
const database_1 = require("@/config/database");
const errorHandler_1 = require("@/middleware/errorHandler");
const getDashboardStats = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, platform } = req.query;
        const where = { userId };
        if (platform && platform !== 'all') {
            where.platform = platform;
        }
        const campaignStats = await database_1.prisma.campaign.aggregate({
            where,
            _count: { id: true },
            _sum: { budget: true }
        });
        const performanceWhere = {};
        if (startDate && endDate) {
            performanceWhere.date = {
                gte: new Date(startDate),
                lte: new Date(endDate)
            };
        }
        const performanceStats = await database_1.prisma.campaignPerformance.aggregate({
            where: performanceWhere,
            _sum: {
                impressions: true,
                clicks: true,
                spend: true,
                conversions: true,
                conversionsValue: true
            },
            _avg: {
                ctr: true,
                cpc: true,
                cpm: true,
                roas: true
            }
        });
        const recentCampaigns = await database_1.prisma.campaign.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            take: 5,
            select: {
                id: true,
                name: true,
                platform: true,
                status: true,
                budget: true,
                createdAt: true
            }
        });
        res.json({
            success: true,
            data: {
                stats: {
                    totalCampaigns: campaignStats._count.id,
                    totalBudget: campaignStats._sum.budget || 0,
                    totalImpressions: performanceStats._sum.impressions || 0,
                    totalClicks: performanceStats._sum.clicks || 0,
                    totalSpend: performanceStats._sum.spend || 0,
                    totalConversions: performanceStats._sum.conversions || 0,
                    totalConversionsValue: performanceStats._sum.conversionsValue || 0,
                    avgCtr: performanceStats._avg.ctr || 0,
                    avgCpc: performanceStats._avg.cpc || 0,
                    avgCpm: performanceStats._avg.cpm || 0,
                    avgRoas: performanceStats._avg.roas || 0
                },
                recentCampaigns
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getDashboardStats = getDashboardStats;
const getCampaignAnalytics = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, campaignIds, platform } = req.query;
        const where = { userId };
        if (platform && platform !== 'all') {
            where.platform = platform;
        }
        if (campaignIds) {
            where.id = { in: campaignIds.split(',') };
        }
        const campaigns = await database_1.prisma.campaign.findMany({
            where,
            include: {
                performance: {
                    where: startDate && endDate ? {
                        date: {
                            gte: new Date(startDate),
                            lte: new Date(endDate)
                        }
                    } : undefined,
                    orderBy: { date: 'desc' }
                }
            }
        });
        res.json({
            success: true,
            data: { campaigns }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaignAnalytics = getCampaignAnalytics;
const getPlatformAnalytics = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { platform, startDate, endDate } = req.query;
        if (!platform || !['google', 'microsoft', 'youtube'].includes(platform)) {
            throw new errorHandler_1.ApiError('Valid platform is required', 400);
        }
        const where = { userId, platform };
        const performanceWhere = {};
        if (startDate && endDate) {
            performanceWhere.date = {
                gte: new Date(startDate),
                lte: new Date(endDate)
            };
        }
        const campaigns = await database_1.prisma.campaign.findMany({
            where,
            include: {
                performance: {
                    where: performanceWhere,
                    orderBy: { date: 'desc' }
                }
            }
        });
        const platformStats = campaigns.reduce((acc, campaign) => {
            const campaignPerformance = campaign.performance.reduce((campAcc, perf) => ({
                impressions: campAcc.impressions + perf.impressions,
                clicks: campAcc.clicks + perf.clicks,
                spend: campAcc.spend + perf.spend,
                conversions: campAcc.conversions + perf.conversions,
                conversionsValue: campAcc.conversionsValue + perf.conversionsValue
            }), { impressions: 0, clicks: 0, spend: 0, conversions: 0, conversionsValue: 0 });
            return {
                impressions: acc.impressions + campaignPerformance.impressions,
                clicks: acc.clicks + campaignPerformance.clicks,
                spend: acc.spend + campaignPerformance.spend,
                conversions: acc.conversions + campaignPerformance.conversions,
                conversionsValue: acc.conversionsValue + campaignPerformance.conversionsValue,
                campaigns: acc.campaigns + 1
            };
        }, { impressions: 0, clicks: 0, spend: 0, conversions: 0, conversionsValue: 0, campaigns: 0 });
        res.json({
            success: true,
            data: {
                platform,
                stats: platformStats,
                campaigns
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getPlatformAnalytics = getPlatformAnalytics;
const getConversionAnalytics = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, campaignId } = req.query;
        const where = {};
        if (startDate && endDate) {
            where.date = {
                gte: new Date(startDate),
                lte: new Date(endDate)
            };
        }
        if (campaignId) {
            where.campaignId = campaignId;
        }
        else {
            const userCampaigns = await database_1.prisma.campaign.findMany({
                where: { userId },
                select: { id: true }
            });
            where.campaignId = { in: userCampaigns.map(c => c.id) };
        }
        const conversions = await database_1.prisma.campaignPerformance.findMany({
            where,
            orderBy: { date: 'desc' },
            include: {
                campaign: {
                    select: {
                        id: true,
                        name: true,
                        platform: true
                    }
                }
            }
        });
        res.json({
            success: true,
            data: { conversions }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getConversionAnalytics = getConversionAnalytics;
const getKeywordPerformance = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, campaignId, platform } = req.query;
        res.json({
            success: true,
            message: 'Keyword performance tracking not yet implemented',
            data: { keywords: [] }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getKeywordPerformance = getKeywordPerformance;
const getAudienceInsights = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, campaignId } = req.query;
        res.json({
            success: true,
            message: 'Audience insights not yet implemented',
            data: { insights: [] }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getAudienceInsights = getAudienceInsights;
const exportAnalytics = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { startDate, endDate, format, type } = req.query;
        res.json({
            success: true,
            message: 'Data export not yet implemented',
            data: { downloadUrl: null }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.exportAnalytics = exportAnalytics;
//# sourceMappingURL=analyticsController.js.map