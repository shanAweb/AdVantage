import { Request, Response, NextFunction } from 'express';
export declare const getDashboardStats: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getCampaignAnalytics: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getPlatformAnalytics: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getConversionAnalytics: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getKeywordPerformance: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getAudienceInsights: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const exportAnalytics: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=analyticsController.d.ts.map