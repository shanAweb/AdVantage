"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCampaignPerformance = exports.resumeCampaign = exports.pauseCampaign = exports.launchCampaign = exports.deleteCampaign = exports.updateCampaign = exports.getCampaign = exports.getCampaigns = exports.createCampaign = void 0;
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const createCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { name, platform, budget, targetAudience, keywords, adGroups } = req.body;
        const campaign = await database_1.prisma.campaign.create({
            data: {
                userId,
                name,
                platform,
                budget,
                targetAudience,
                keywords,
                adGroups,
                status: 'draft'
            }
        });
        logger_1.logger.info('Campaign created', { campaignId: campaign.id, userId, platform });
        res.status(201).json({
            success: true,
            message: 'Campaign created successfully',
            data: { campaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createCampaign = createCampaign;
const getCampaigns = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 1, limit = 10, platform, status } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const where = { userId };
        if (platform)
            where.platform = platform;
        if (status)
            where.status = status;
        const [campaigns, total] = await Promise.all([
            database_1.prisma.campaign.findMany({
                where,
                skip,
                take,
                orderBy: { createdAt: 'desc' },
                include: {
                    _count: {
                        select: {
                            performance: true
                        }
                    }
                }
            }),
            database_1.prisma.campaign.count({ where })
        ]);
        res.json({
            success: true,
            data: {
                campaigns,
                pagination: {
                    page: Number(page),
                    limit: Number(limit),
                    total,
                    pages: Math.ceil(total / Number(limit))
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaigns = getCampaigns;
const getCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId },
            include: {
                adGroups_rel: true,
                performance: {
                    orderBy: { date: 'desc' },
                    take: 30
                }
            }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        res.json({
            success: true,
            data: { campaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaign = getCampaign;
const updateCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const updateData = req.body;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        const updatedCampaign = await database_1.prisma.campaign.update({
            where: { id },
            data: updateData
        });
        logger_1.logger.info('Campaign updated', { campaignId: id, userId, updatedFields: Object.keys(updateData) });
        res.json({
            success: true,
            message: 'Campaign updated successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateCampaign = updateCampaign;
const deleteCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        await database_1.prisma.campaign.delete({
            where: { id }
        });
        logger_1.logger.info('Campaign deleted', { campaignId: id, userId });
        res.json({
            success: true,
            message: 'Campaign deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteCampaign = deleteCampaign;
const launchCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        if (campaign.status !== 'draft') {
            throw new errorHandler_1.ApiError('Only draft campaigns can be launched', 400);
        }
        const updatedCampaign = await database_1.prisma.campaign.update({
            where: { id },
            data: { status: 'active' }
        });
        logger_1.logger.info('Campaign launched', { campaignId: id, userId, platform: campaign.platform });
        res.json({
            success: true,
            message: 'Campaign launched successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.launchCampaign = launchCampaign;
const pauseCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        if (campaign.status !== 'active') {
            throw new errorHandler_1.ApiError('Only active campaigns can be paused', 400);
        }
        const updatedCampaign = await database_1.prisma.campaign.update({
            where: { id },
            data: { status: 'paused' }
        });
        logger_1.logger.info('Campaign paused', { campaignId: id, userId });
        res.json({
            success: true,
            message: 'Campaign paused successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.pauseCampaign = pauseCampaign;
const resumeCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        if (campaign.status !== 'paused') {
            throw new errorHandler_1.ApiError('Only paused campaigns can be resumed', 400);
        }
        const updatedCampaign = await database_1.prisma.campaign.update({
            where: { id },
            data: { status: 'active' }
        });
        logger_1.logger.info('Campaign resumed', { campaignId: id, userId });
        res.json({
            success: true,
            message: 'Campaign resumed successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.resumeCampaign = resumeCampaign;
const getCampaignPerformance = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { startDate, endDate } = req.query;
        const campaign = await database_1.prisma.campaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        const where = { campaignId: id };
        if (startDate && endDate) {
            where.date = {
                gte: new Date(startDate),
                lte: new Date(endDate)
            };
        }
        const performance = await database_1.prisma.campaignPerformance.findMany({
            where,
            orderBy: { date: 'desc' }
        });
        res.json({
            success: true,
            data: { performance }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaignPerformance = getCampaignPerformance;
//# sourceMappingURL=campaignController.js.map