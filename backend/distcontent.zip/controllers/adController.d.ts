import { Request, Response, NextFunction } from 'express';
export declare const createAd: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getAds: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getAd: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const updateAd: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const deleteAd: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const bulkCreateAds: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=adController.d.ts.map