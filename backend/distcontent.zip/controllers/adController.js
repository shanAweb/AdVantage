"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bulkCreateAds = exports.deleteAd = exports.updateAd = exports.getAd = exports.getAds = exports.createAd = void 0;
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const createAd = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { feedId, productId, headline, description } = req.body;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id: feedId, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const product = await database_1.prisma.product.findFirst({
            where: { id: productId, feedId }
        });
        if (!product) {
            throw new errorHandler_1.ApiError('Product not found', 404);
        }
        const ad = await database_1.prisma.ad.create({
            data: {
                userId,
                feedId,
                productId,
                headline: headline || product.title,
                description: description || product.description || '',
                finalUrl: product.link,
                imageUrl: product.imageUrl,
            },
            include: {
                product: true,
                feed: true,
            }
        });
        logger_1.logger.info('Ad created', { adId: ad.id, userId, feedId, productId });
        res.status(201).json({
            success: true,
            message: 'Ad created successfully',
            data: { ad }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createAd = createAd;
const getAds = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 1, limit = 20, feedId, search } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const where = { userId };
        if (feedId)
            where.feedId = feedId;
        if (search) {
            where.OR = [
                { headline: { contains: search, mode: 'insensitive' } },
                { description: { contains: search, mode: 'insensitive' } },
                { product: { title: { contains: search, mode: 'insensitive' } } }
            ];
        }
        const [ads, total] = await Promise.all([
            database_1.prisma.ad.findMany({
                where,
                skip,
                take,
                orderBy: { createdAt: 'desc' },
                include: {
                    product: {
                        select: {
                            id: true,
                            title: true,
                            price: true,
                            currency: true,
                            imageUrl: true,
                        }
                    },
                    feed: {
                        select: {
                            id: true,
                            name: true,
                        }
                    },
                    campaigns: {
                        include: {
                            campaign: {
                                select: {
                                    id: true,
                                    name: true,
                                    status: true,
                                    channel: true,
                                }
                            }
                        }
                    },
                    _count: {
                        select: {
                            campaigns: true,
                        }
                    }
                }
            }),
            database_1.prisma.ad.count({ where })
        ]);
        res.json({
            success: true,
            data: {
                ads,
                pagination: {
                    page: Number(page),
                    limit: Number(limit),
                    total,
                    pages: Math.ceil(total / Number(limit))
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getAds = getAds;
const getAd = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const ad = await database_1.prisma.ad.findFirst({
            where: { id, userId },
            include: {
                product: true,
                feed: {
                    select: {
                        id: true,
                        name: true,
                        siteUrl: true,
                    }
                },
                campaigns: {
                    include: {
                        campaign: {
                            select: {
                                id: true,
                                name: true,
                                status: true,
                                channel: true,
                                budget: true,
                                currency: true,
                                country: true,
                            }
                        }
                    }
                }
            }
        });
        if (!ad) {
            throw new errorHandler_1.ApiError('Ad not found', 404);
        }
        res.json({
            success: true,
            data: { ad }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getAd = getAd;
const updateAd = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const updateData = req.body;
        const ad = await database_1.prisma.ad.findFirst({
            where: { id, userId }
        });
        if (!ad) {
            throw new errorHandler_1.ApiError('Ad not found', 404);
        }
        const updatedAd = await database_1.prisma.ad.update({
            where: { id },
            data: updateData,
            include: {
                product: true,
                feed: {
                    select: {
                        id: true,
                        name: true,
                    }
                }
            }
        });
        logger_1.logger.info('Ad updated', { adId: id, userId, updatedFields: Object.keys(updateData) });
        res.json({
            success: true,
            message: 'Ad updated successfully',
            data: { ad: updatedAd }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateAd = updateAd;
const deleteAd = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const ad = await database_1.prisma.ad.findFirst({
            where: { id, userId }
        });
        if (!ad) {
            throw new errorHandler_1.ApiError('Ad not found', 404);
        }
        await database_1.prisma.ad.delete({
            where: { id }
        });
        logger_1.logger.info('Ad deleted', { adId: id, userId });
        res.json({
            success: true,
            message: 'Ad deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteAd = deleteAd;
const bulkCreateAds = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { feedId, productIds, headlineTemplate, descriptionTemplate } = req.body;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id: feedId, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        const products = await database_1.prisma.product.findMany({
            where: {
                id: { in: productIds },
                feedId
            }
        });
        if (products.length === 0) {
            throw new errorHandler_1.ApiError('No valid products found', 404);
        }
        const ads = await Promise.all(products.map(product => database_1.prisma.ad.create({
            data: {
                userId,
                feedId,
                productId: product.id,
                headline: headlineTemplate
                    ? headlineTemplate.replace('{title}', product.title)
                    : product.title,
                description: descriptionTemplate
                    ? descriptionTemplate.replace('{description}', product.description || '')
                    : product.description || '',
                finalUrl: product.link,
                imageUrl: product.imageUrl,
            },
            include: {
                product: true,
            }
        })));
        logger_1.logger.info('Bulk ads created', { userId, feedId, count: ads.length });
        res.status(201).json({
            success: true,
            message: `${ads.length} ads created successfully`,
            data: { ads }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.bulkCreateAds = bulkCreateAds;
//# sourceMappingURL=adController.js.map