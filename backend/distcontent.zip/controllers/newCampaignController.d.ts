import { Request, Response, NextFunction } from 'express';
export declare const createCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getCampaigns: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const updateCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const deleteCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const addAdsToCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const removeAdsFromCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const launchCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const pauseCampaign: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=newCampaignController.d.ts.map