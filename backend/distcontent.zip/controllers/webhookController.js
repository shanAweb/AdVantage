"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.youtubeWebhook = exports.microsoftAdsWebhook = exports.googleAdsWebhook = exports.stripeWebhook = void 0;
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const stripeWebhook = async (req, res, next) => {
    try {
        const { type, data } = req.body;
        await database_1.prisma.webhookEvent.create({
            data: {
                platform: 'stripe',
                eventType: type,
                payload: data
            }
        });
        switch (type) {
            case 'customer.subscription.created':
            case 'customer.subscription.updated':
                logger_1.logger.info('Stripe subscription event', { type, subscriptionId: data.object.id });
                break;
            case 'customer.subscription.deleted':
                logger_1.logger.info('Stripe subscription cancelled', { subscriptionId: data.object.id });
                break;
            case 'invoice.payment_succeeded':
                logger_1.logger.info('Stripe payment succeeded', { invoiceId: data.object.id });
                break;
            case 'invoice.payment_failed':
                logger_1.logger.info('Stripe payment failed', { invoiceId: data.object.id });
                break;
            default:
                logger_1.logger.info('Unhandled Stripe webhook event', { type });
        }
        res.json({ success: true, message: 'Webhook processed' });
    }
    catch (error) {
        logger_1.logger.error('Stripe webhook error:', error);
        next(error);
    }
};
exports.stripeWebhook = stripeWebhook;
const googleAdsWebhook = async (req, res, next) => {
    try {
        const { eventType, resourceName } = req.body;
        await database_1.prisma.webhookEvent.create({
            data: {
                platform: 'google',
                eventType,
                payload: { resourceName }
            }
        });
        switch (eventType) {
            case 'campaign.created':
                logger_1.logger.info('Google Ads campaign created', { resourceName });
                break;
            case 'campaign.updated':
                logger_1.logger.info('Google Ads campaign updated', { resourceName });
                break;
            case 'campaign.paused':
                logger_1.logger.info('Google Ads campaign paused', { resourceName });
                break;
            case 'campaign.resumed':
                logger_1.logger.info('Google Ads campaign resumed', { resourceName });
                break;
            default:
                logger_1.logger.info('Unhandled Google Ads webhook event', { eventType });
        }
        res.json({ success: true, message: 'Webhook processed' });
    }
    catch (error) {
        logger_1.logger.error('Google Ads webhook error:', error);
        next(error);
    }
};
exports.googleAdsWebhook = googleAdsWebhook;
const microsoftAdsWebhook = async (req, res, next) => {
    try {
        const { eventType, resourceId } = req.body;
        await database_1.prisma.webhookEvent.create({
            data: {
                platform: 'microsoft',
                eventType,
                payload: { resourceId }
            }
        });
        switch (eventType) {
            case 'campaign.created':
                logger_1.logger.info('Microsoft Ads campaign created', { resourceId });
                break;
            case 'campaign.updated':
                logger_1.logger.info('Microsoft Ads campaign updated', { resourceId });
                break;
            case 'campaign.paused':
                logger_1.logger.info('Microsoft Ads campaign paused', { resourceId });
                break;
            case 'campaign.resumed':
                logger_1.logger.info('Microsoft Ads campaign resumed', { resourceId });
                break;
            default:
                logger_1.logger.info('Unhandled Microsoft Ads webhook event', { eventType });
        }
        res.json({ success: true, message: 'Webhook processed' });
    }
    catch (error) {
        logger_1.logger.error('Microsoft Ads webhook error:', error);
        next(error);
    }
};
exports.microsoftAdsWebhook = microsoftAdsWebhook;
const youtubeWebhook = async (req, res, next) => {
    try {
        const { eventType, videoId } = req.body;
        await database_1.prisma.webhookEvent.create({
            data: {
                platform: 'youtube',
                eventType,
                payload: { videoId }
            }
        });
        switch (eventType) {
            case 'video.uploaded':
                logger_1.logger.info('YouTube video uploaded', { videoId });
                break;
            case 'video.published':
                logger_1.logger.info('YouTube video published', { videoId });
                break;
            case 'video.updated':
                logger_1.logger.info('YouTube video updated', { videoId });
                break;
            case 'video.deleted':
                logger_1.logger.info('YouTube video deleted', { videoId });
                break;
            default:
                logger_1.logger.info('Unhandled YouTube webhook event', { eventType });
        }
        res.json({ success: true, message: 'Webhook processed' });
    }
    catch (error) {
        logger_1.logger.error('YouTube webhook error:', error);
        next(error);
    }
};
exports.youtubeWebhook = youtubeWebhook;
//# sourceMappingURL=webhookController.js.map