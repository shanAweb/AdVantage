"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pauseCampaign = exports.launchCampaign = exports.removeAdsFromCampaign = exports.addAdsToCampaign = exports.deleteCampaign = exports.updateCampaign = exports.getCampaign = exports.getCampaigns = exports.createCampaign = void 0;
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const createCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { feedId, name, channel, budget, currency, country, adIds } = req.body;
        const feed = await database_1.prisma.feed.findFirst({
            where: { id: feedId, userId }
        });
        if (!feed) {
            throw new errorHandler_1.ApiError('Feed not found', 404);
        }
        if (adIds && adIds.length > 0) {
            const ads = await database_1.prisma.ad.findMany({
                where: {
                    id: { in: adIds },
                    userId,
                    feedId
                }
            });
            if (ads.length !== adIds.length) {
                throw new errorHandler_1.ApiError('Some ads not found or do not belong to this feed', 400);
            }
        }
        const campaign = await database_1.prisma.newCampaign.create({
            data: {
                userId,
                feedId,
                name,
                channel,
                budget,
                currency: currency || 'USD',
                country,
                status: 'draft',
            },
            include: {
                feed: {
                    select: {
                        id: true,
                        name: true,
                        siteUrl: true,
                    }
                }
            }
        });
        if (adIds && adIds.length > 0) {
            await database_1.prisma.newCampaignAd.createMany({
                data: adIds.map((adId) => ({
                    campaignId: campaign.id,
                    adId,
                }))
            });
        }
        const campaignWithAds = await database_1.prisma.newCampaign.findUnique({
            where: { id: campaign.id },
            include: {
                feed: {
                    select: {
                        id: true,
                        name: true,
                        siteUrl: true,
                    }
                },
                ads: {
                    include: {
                        ad: {
                            include: {
                                product: {
                                    select: {
                                        id: true,
                                        title: true,
                                        price: true,
                                        currency: true,
                                        imageUrl: true,
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        logger_1.logger.info('Campaign created', { campaignId: campaign.id, userId, feedId, adCount: adIds?.length || 0 });
        res.status(201).json({
            success: true,
            message: 'Campaign created successfully',
            data: { campaign: campaignWithAds }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createCampaign = createCampaign;
const getCampaigns = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 1, limit = 10, feedId, status, channel } = req.query;
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const where = { userId };
        if (feedId)
            where.feedId = feedId;
        if (status)
            where.status = status;
        if (channel)
            where.channel = channel;
        const [campaigns, total] = await Promise.all([
            database_1.prisma.newCampaign.findMany({
                where,
                skip,
                take,
                orderBy: { createdAt: 'desc' },
                include: {
                    feed: {
                        select: {
                            id: true,
                            name: true,
                            siteUrl: true,
                        }
                    },
                    ads: {
                        include: {
                            ad: {
                                select: {
                                    id: true,
                                    headline: true,
                                    description: true,
                                    imageUrl: true,
                                    product: {
                                        select: {
                                            id: true,
                                            title: true,
                                            price: true,
                                            currency: true,
                                        }
                                    }
                                }
                            }
                        }
                    },
                    _count: {
                        select: {
                            ads: true,
                        }
                    }
                }
            }),
            database_1.prisma.newCampaign.count({ where })
        ]);
        res.json({
            success: true,
            data: {
                campaigns,
                pagination: {
                    page: Number(page),
                    limit: Number(limit),
                    total,
                    pages: Math.ceil(total / Number(limit))
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaigns = getCampaigns;
const getCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId },
            include: {
                feed: {
                    select: {
                        id: true,
                        name: true,
                        siteUrl: true,
                        country: true,
                        currency: true,
                    }
                },
                ads: {
                    include: {
                        ad: {
                            include: {
                                product: {
                                    select: {
                                        id: true,
                                        title: true,
                                        description: true,
                                        price: true,
                                        currency: true,
                                        imageUrl: true,
                                        link: true,
                                        availability: true,
                                        brand: true,
                                        category: true,
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        res.json({
            success: true,
            data: { campaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getCampaign = getCampaign;
const updateCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const updateData = req.body;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        const updatedCampaign = await database_1.prisma.newCampaign.update({
            where: { id },
            data: updateData,
            include: {
                feed: {
                    select: {
                        id: true,
                        name: true,
                        siteUrl: true,
                    }
                },
                ads: {
                    include: {
                        ad: {
                            include: {
                                product: {
                                    select: {
                                        id: true,
                                        title: true,
                                        price: true,
                                        currency: true,
                                        imageUrl: true,
                                    }
                                }
                            }
                        }
                    }
                }
            }
        });
        logger_1.logger.info('Campaign updated', { campaignId: id, userId, updatedFields: Object.keys(updateData) });
        res.json({
            success: true,
            message: 'Campaign updated successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateCampaign = updateCampaign;
const deleteCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        await database_1.prisma.newCampaign.delete({
            where: { id }
        });
        logger_1.logger.info('Campaign deleted', { campaignId: id, userId });
        res.json({
            success: true,
            message: 'Campaign deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteCampaign = deleteCampaign;
const addAdsToCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { adIds } = req.body;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        const ads = await database_1.prisma.ad.findMany({
            where: {
                id: { in: adIds },
                userId,
                feedId: campaign.feedId
            }
        });
        if (ads.length !== adIds.length) {
            throw new errorHandler_1.ApiError('Some ads not found or do not belong to this feed', 400);
        }
        await database_1.prisma.newCampaignAd.createMany({
            data: adIds.map((adId) => ({
                campaignId: campaign.id,
                adId,
            })),
            skipDuplicates: true
        });
        logger_1.logger.info('Ads added to campaign', { campaignId: id, userId, adCount: adIds.length });
        res.json({
            success: true,
            message: `${adIds.length} ads added to campaign successfully`
        });
    }
    catch (error) {
        next(error);
    }
};
exports.addAdsToCampaign = addAdsToCampaign;
const removeAdsFromCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const { adIds } = req.body;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        await database_1.prisma.newCampaignAd.deleteMany({
            where: {
                campaignId: campaign.id,
                adId: { in: adIds }
            }
        });
        logger_1.logger.info('Ads removed from campaign', { campaignId: id, userId, adCount: adIds.length });
        res.json({
            success: true,
            message: `${adIds.length} ads removed from campaign successfully`
        });
    }
    catch (error) {
        next(error);
    }
};
exports.removeAdsFromCampaign = removeAdsFromCampaign;
const launchCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId },
            include: {
                _count: {
                    select: {
                        ads: true
                    }
                }
            }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        if (campaign.status !== 'draft') {
            throw new errorHandler_1.ApiError('Only draft campaigns can be launched', 400);
        }
        if (campaign._count.ads === 0) {
            throw new errorHandler_1.ApiError('Campaign must have at least one ad to launch', 400);
        }
        const updatedCampaign = await database_1.prisma.newCampaign.update({
            where: { id },
            data: { status: 'active' }
        });
        logger_1.logger.info('Campaign launched', { campaignId: id, userId, channel: campaign.channel });
        res.json({
            success: true,
            message: 'Campaign launched successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.launchCampaign = launchCampaign;
const pauseCampaign = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { id } = req.params;
        const campaign = await database_1.prisma.newCampaign.findFirst({
            where: { id, userId }
        });
        if (!campaign) {
            throw new errorHandler_1.ApiError('Campaign not found', 404);
        }
        if (campaign.status !== 'active') {
            throw new errorHandler_1.ApiError('Only active campaigns can be paused', 400);
        }
        const updatedCampaign = await database_1.prisma.newCampaign.update({
            where: { id },
            data: { status: 'paused' }
        });
        logger_1.logger.info('Campaign paused', { campaignId: id, userId });
        res.json({
            success: true,
            message: 'Campaign paused successfully',
            data: { campaign: updatedCampaign }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.pauseCampaign = pauseCampaign;
//# sourceMappingURL=newCampaignController.js.map