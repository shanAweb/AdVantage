"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteAccount = exports.updateSubscription = exports.getUserStats = exports.changePassword = exports.updateProfile = exports.getProfile = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_1 = require("@/config/database");
const logger_1 = require("@/utils/logger");
const errorHandler_1 = require("@/middleware/errorHandler");
const getProfile = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const user = await database_1.prisma.user.findUnique({
            where: { id: userId },
            include: {
                subscription: true,
                _count: {
                    select: {
                        campaigns: true,
                        integrations: true
                    }
                }
            }
        });
        if (!user) {
            throw new errorHandler_1.ApiError('User not found', 404);
        }
        res.json({
            success: true,
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    company: user.company,
                    phone: user.phone,
                    timezone: user.timezone,
                    createdAt: user.createdAt,
                    updatedAt: user.updatedAt,
                    subscription: user.subscription,
                    stats: {
                        campaignsCount: user._count.campaigns,
                        integrationsCount: user._count.integrations
                    }
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getProfile = getProfile;
const updateProfile = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { firstName, lastName, company, phone, timezone } = req.body;
        const user = await database_1.prisma.user.update({
            where: { id: userId },
            data: {
                ...(firstName && { firstName }),
                ...(lastName && { lastName }),
                ...(company !== undefined && { company }),
                ...(phone !== undefined && { phone }),
                ...(timezone && { timezone })
            },
            include: {
                subscription: true
            }
        });
        logger_1.logger.info('User profile updated', { userId, updatedFields: Object.keys(req.body) });
        res.json({
            success: true,
            message: 'Profile updated successfully',
            data: {
                user: {
                    id: user.id,
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    company: user.company,
                    phone: user.phone,
                    timezone: user.timezone,
                    subscription: user.subscription
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateProfile = updateProfile;
const changePassword = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { currentPassword, newPassword } = req.body;
        const user = await database_1.prisma.user.findUnique({
            where: { id: userId }
        });
        if (!user) {
            throw new errorHandler_1.ApiError('User not found', 404);
        }
        const isCurrentPasswordValid = await bcryptjs_1.default.compare(currentPassword, user.password);
        if (!isCurrentPasswordValid) {
            throw new errorHandler_1.ApiError('Current password is incorrect', 400);
        }
        const saltRounds = 12;
        const hashedPassword = await bcryptjs_1.default.hash(newPassword, saltRounds);
        await database_1.prisma.user.update({
            where: { id: userId },
            data: { password: hashedPassword }
        });
        await database_1.prisma.refreshToken.deleteMany({
            where: { userId }
        });
        logger_1.logger.info('User password changed', { userId });
        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.changePassword = changePassword;
const getUserStats = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const campaignStats = await database_1.prisma.campaign.aggregate({
            where: { userId },
            _count: {
                id: true
            },
            _sum: {
                budget: true
            }
        });
        const activeCampaigns = await database_1.prisma.campaign.count({
            where: {
                userId,
                status: 'active'
            }
        });
        const totalSpend = 0;
        const totalConversions = 0;
        res.json({
            success: true,
            data: {
                stats: {
                    totalCampaigns: campaignStats._count.id,
                    activeCampaigns,
                    totalBudget: campaignStats._sum.budget || 0,
                    totalSpend,
                    totalConversions
                }
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getUserStats = getUserStats;
const updateSubscription = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { planId, paymentMethodId } = req.body;
        const subscription = await database_1.prisma.subscription.update({
            where: { userId },
            data: {
                planId,
                status: 'active',
                currentPeriodStart: new Date(),
                currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
            }
        });
        logger_1.logger.info('User subscription updated', { userId, planId });
        res.json({
            success: true,
            message: 'Subscription updated successfully',
            data: {
                subscription
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateSubscription = updateSubscription;
const deleteAccount = async (req, res, next) => {
    try {
        const userId = req.user.id;
        await database_1.prisma.user.delete({
            where: { id: userId }
        });
        logger_1.logger.info('User account deleted', { userId });
        res.json({
            success: true,
            message: 'Account deleted successfully'
        });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteAccount = deleteAccount;
//# sourceMappingURL=userController.js.map